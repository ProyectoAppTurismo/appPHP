<?php
include_once 'sqlite/baseDatos.php';

function modeloCrearVariables(){
	$compañia=$_GET['cia'];
	$tipo=$_GET['tipo'];
	$precio=$_GET['precio'];
	$afluencia=$_GET['afluencia'];
	$tipotur=$_GET['tipotur'];
}
function modeloConsulta(){
	
}

